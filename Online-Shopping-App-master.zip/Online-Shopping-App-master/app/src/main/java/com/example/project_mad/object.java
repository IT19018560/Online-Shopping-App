package com.example.project_mad;

public class object {
}
