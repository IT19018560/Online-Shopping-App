package com.example.project_mad;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class PlaceOrderActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_place_order);
    }
}